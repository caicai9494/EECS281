#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void array2Dsearch(vector<vector<int> > & array2D, int item) {
	for(int i = 0; i < array2D.size(); ++i) { 							// n steps
		if(binary_search(array2D[i].begin(), array2D[i].end(), item)) {	// log(n) operation
			cout << "found " << item << '\n';							// 1 step
			return;														// 1 step
		}
	}
	cout << "did not find " << item << '\n';							// 1 step
}


int main() {
	vector<vector<int> > array2D;
	for(int i = 0; i < 100; i+=10) {
		vector<int> array1D;
		for(int j = 0; j < 10; j++) {
			array1D.push_back(i+j);
		}
		array2D.push_back(array1D);
	}
	array2Dsearch(array2D, 75);
}
