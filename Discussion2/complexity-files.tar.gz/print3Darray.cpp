#include <vector>
#include <iostream>

using namespace std;


// what is the complexity?
int main() {
	int size = 10;
	int count = 0;
	vector<vector<vector<int> > > cube;
	for(int i = 0; i < size; ++i) {
		cout << "\n next level \n";
		vector<vector<int> > section;
		for(int j = 0; j < size; ++j) {
			vector<int> row;
			for(int k = 0; k < size; ++k) {
				row.push_back(count);
				cout << count++ << ' ';
			}
			section.push_back(row);
			cout << '\n';
		}
		cube.push_back(section);
	}
	
	cout << "\n\n ------ FINISHED ------ \n\n";
}
