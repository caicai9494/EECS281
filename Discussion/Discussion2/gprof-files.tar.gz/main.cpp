#include <iostream>
#include <sstream>
using namespace std;

const int n = 100000;

//1. cout with endl
void func1(){
	for(int i=0; i<n; i++) cout << "yolo" << endl;
}

//2. cout with \n
void func2(){
	for(int i=0; i<n; i++) cout << "yolo\n";
}

//3. stringstream buffer
void func3(){
	stringstream ss;
	for(int i=0; i<n; i++) ss << "yolo\n";
	cout << ss.str();
}

//4. c-style i/o
void func4(){
	for(int i=0; i<n; i++) printf("yolo\n");
}

int main(){
	cout << "Hello World\n";
	for(int i=0; i<10; i++){
		func1();
		func2();
		func3();
		func4();
	}	
	return 0;
}

