#ifndef CLASS_H
#define CLASS_H

class Class {
    long a, b;

public:
    Class(long x, long y) : a(x), b(y) {}
    void display() const;
};

#endif
