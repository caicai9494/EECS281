// project0.cpp
//
// The Makefile expects that the project solution has main() in a file
// named project*.cpp
//
// The project can be built in a number of ways:
//  $ make              // An easy way to compile and link everything with O3
//  $ make release      // ibid.
//  $ make all          // ibid.
//  $ make -R -r        // This is what the autograder does!
//  $ make debug        // Make with debug flag set for gdb and/or valgrind
//  $ make profile      // For profiling the project code with gprof or others

#include <iostream>
using std::cin;
#include <getopt.h>

#include "class.h"

int main() {
    int num_values;
    long x, y;

    // Use getopt_long here, to get command line options

    cin >> num_values;
    while (cin >> x >> y) {
        Class c(x, y);
        c.display();
    }

    return 0;
}
