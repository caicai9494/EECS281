EECS 281 - Project 0
====================

This example project is a multi-file solution for a simple, but nonexistant
EECS 281 project. Included are the following files:

* Makefile
* project0.cpp
* class.h, class.cpp
* test_class.cpp
* test_data.txt

### Makefile

This is the "EECS 281 Advanced Makefile". It attempts to do all things for all
people in EECS 281. This lofty goal is far from achieveable, but when used
correctly, this Makefile can really "make" your life easy!

There are 3 sections in the file that need to be customized for each project.

* An _EXECUTABLE_ variable needs to be set, following the instructions given in whatever project for which your solution is written.
* A _PROJECTFILE_ variable needs to be set, naming the file with the main() function for your solution.
* A _DEPENDENCIES_ section needs to be edited to include any custom file dependencies your solution requires. Project 0 has two custom dependencies, one for the standalone class and one for the full solution that includes the standalone class.

For more information about how to use this Makefile, see the [documentation
page for make](http://linux.die.net/man/1/make). There will be a segment on
make and this Makefile in discussion section. You can also come to office
hours for additional help with make/Makefile.

### project0.cpp

This is the _PROJECTFILE_ for Project 0, it contains a simple main() that
would be responsible for the execution of a solution. It incorporates a
standalone class, from the files described below.

If you reuse this solution structure and Makefile for your EECS 281 projects,
make sure to put your solution's main() in a file named with the project*.cpp
glob pattern (filename starts with "project" all lowercase, ends with ".cpp").

### class.h, class.cpp

This is a standalone class, for use in an Object Oriented (OO) solution. It
consists of a class declaration (class.h) and a class definition (class.cpp).

Using classes in your solutions has benefits. For starters C++ is an Object
Oriented language, so by learning and using classes, you will be leveraging a
major feature of the language you are required to use in this course. A second
benefit is that the source code modularity that OO programs require can make
your programs easier to write, test, debug, and read.

### test_class.cpp

This file will make a "test executable". It includes a main(), but not the
one from the solution. This main() function is strictly for testing the
standalone class described in the section above.

When used the Makefile included in Project 0, you can build this test with
either 'make test_class' or 'make alltests'.

The Makefile supports testing by automatically creating build recipes for any
source file that matches the test*.cpp glob pattern (filename starts with
"test" all lowercase, and ends with ".cpp"). A file named "testX.cpp" will
automatically be built into an executable named "testX" with either 'make
testX' or 'make alltests'. These tests will not interfere with your solution
main(), can access any modules you write outside of _PROJECTFILE_, and will
not be included in submissions built using the Makefile (either 'make
fullsubmit' or 'make partialsubmit').

### test_data.txt

This is a simple text file that is similar to tests you will include in your
submissions to find "bugs" in the instructor solution. It will be included in
your submissions built with 'make fullsubmit', but excluded in submissions
built with 'make partialsubmit'. Full submissions will be subtracted from your
daily allotment on the autograder, even if your project fails to build. On the
other hand, a partial submission that fails to build will not subtract from
your daily allotment on the autograder.
