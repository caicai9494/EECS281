// test_class.cpp
//
// The Makefile expects that the project solution has main() in a file
// named project*.cpp.  For your own testing purposes, .cpp files that
// begin with 'test' can include a main(), that will not conflict with
// the project solution main().  Also, the test*.cpp files will not be
// included in any submission archives.
//
// Tests can be built in two ways:
//  $ make test_class   // Make the test in test_class.cpp with all other
//                      // source (and header) files.
//  $ make alltests     // Make all tests in test*.cpp with all other
//                      // source (and header) files.

#include "class.h"

int main () {
    // Stack
    Class a(0, 0);
    a.display();

    // Heap
    Class *b = new Class(1, 1);
    b->display();
    delete b;

    return 0;
}
