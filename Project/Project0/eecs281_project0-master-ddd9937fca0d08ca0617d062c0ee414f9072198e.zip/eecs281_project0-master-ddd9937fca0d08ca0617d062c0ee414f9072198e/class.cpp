// class.cpp
//
// The Makefile expects that the project solution has main() in a file
// named project*.cpp
//
// This class is declared in class.h and implemented in class.cpp

#include <iostream>
using std::cout;
using std::endl;

#include "class.h"


void Class::display() const {
    cout << "(A, B) = (" << a << ", " << b << ')' << endl;
}
